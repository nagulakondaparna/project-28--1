# Project28
For this summer season Juno is visiting his granny’s home. There he saw a mango tree in granny’s garden and wanted to eat them. Help him pluck some mangoes by throwing a stone. In this game you have to drag the stone and hit the mangoes.(Note: That you can drag the stone after the you realse the mouse the stone will go automatically where the stone is showing).
